package sorting.variationsOfSelectionsort;

import sorting.AbstractSorting;
import util.Util;

public class RecursiveSelectionSort<T extends Comparable<T>> extends
		AbstractSorting<T> {

	/**
	 * Implementação recursiva do selection sort. Você deve implementar apenas
	 * esse método sem usar nenhum outro método auxiliar (exceto
	 * Util.swap(array,int,int)). Para isso, tente definir o caso base do
	 * algoritmo e depois o caso indutivo, que reduz o problema para uma entrada
	 * menor em uma chamada recursiva. Seu algoritmo deve ter complexidade
	 * quadrática O(n^2).
	 */
	@Override
	public void sort(T[] array, int leftIndex, int rightIndex) {
		// Caso base
		if (array == null || array.length == 0
				|| leftIndex < 0
				|| rightIndex >= array.length
				|| leftIndex >= rightIndex) {
			return;
		}

		// Procura o menor elemento
		int minIndex = leftIndex;

		for (int i = leftIndex + 1; i <= rightIndex; i++) {

			if (array[i].compareTo(array[minIndex]) < 0) {
				minIndex = i;
			}
		}

		// Coloca o menor no início
		Util.swap(array, leftIndex, minIndex);

		// Reduz o problema
		sort(array, leftIndex + 1, rightIndex);
	}
}
