package adt.stack;

public class StackImpl<T> implements Stack<T> {

	protected T[] array;
	protected int top;

	@SuppressWarnings("unchecked")
	public StackImpl(int size) {
		array = (T[]) new Object[size];
		top = -1;
	}

	@Override
	public T top() {
		if(isEmpty()) {
			return null;
		}
		return array[top];
	}

	@Override
	public boolean isEmpty() {
		return top == -1;
	}

	@Override
	public boolean isFull() {
		return top == array.length -1;
	}

	@Override
	public void push(T element) throws StackOverflowException {
		if (isFull()) {
            throw new StackOverflowException();
        }
        
        if (element != null) {
            top++;
            array[top] = element;
        }
	}

	@Override
	public T pop() throws StackUnderflowException {
		if(isEmpty()){
			throw new StackUnderflowException();
		}
		T element = array[top];
		array[top] = null;
		top--;
		return element;
	}
}
