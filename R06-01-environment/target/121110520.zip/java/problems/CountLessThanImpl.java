package problems;

public class CountLessThanImpl implements CountLessThan{

    @Override
	public int countLess(Integer[] array, Integer x){
        //TODO replace this line below with your implementation
		throw new UnsupportedOperationException("Not implemented yet!");
    }

}
